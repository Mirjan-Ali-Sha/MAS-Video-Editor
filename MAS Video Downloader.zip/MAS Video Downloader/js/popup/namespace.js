var mvdSingleDownloader = {
	noYoutube: chrome.extension.getBackgroundPage().mvdSingleDownloader.noYoutube,
};